#pragma once
class DMath {
public:
	static bool IsEqual(double Lhs, double Rhs);
};
